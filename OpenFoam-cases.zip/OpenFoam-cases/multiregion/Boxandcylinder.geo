//+ Gmsh project created on Sun Apr  5 09:58:10 2026
SetFactory("OpenCASCADE");
//+ Box
Box(1) = {-0.5, 0, -0.5, 0.2, 1, 1};
//+ Cylinder (longer than box)
Cylinder(2) = {-0.7, 0.5, 0, 1, 0, 0, 0.2, 2*Pi};
//+ Fragment them → THIS creates proper interface
BooleanFragments{ Volume{1}; Delete; }{ Volume{2}; Delete; }
//+
Physical Volume("cyl_big", 20) = {3};
//+
Physical Volume("cyl_small", 21) = {4};
//+
Physical Volume("box_inner", 22) = {1};
//+
Physical Surface("Leftend", 23) = {13};
//+
Physical Surface("Rightend", 24) = {11};
//+
Physical Surface("Interface1", 25) = {8};
//+
Physical Surface("Interface2", 26) = {6};
//+
Physical Surface("Interface3", 27) = {9};
//+
Physical Surface("Lateral1", 28) = {12};
//+
Physical Surface("Lateral2", 29) = {10};
//+
Physical Surface("top", 30) = {5};
//+
Physical Surface("bottom", 31) = {2};
//+
Physical Surface("left", 32) = {1};
//+
Physical Surface("right", 33) = {7};
//+
Physical Surface("front", 34) = {3};
//+
Physical Surface("back", 35) = {4};
