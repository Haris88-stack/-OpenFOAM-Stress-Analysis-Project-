// Gmsh project created on Thu Apr  2 16:47:52 2026
SetFactory("OpenCASCADE");
//+
Circle(1) = {0, -0, 0, 0.5, 0, 2*Pi};
//+
Circle(2) = {0, 0, 0, 0.40, 0, 2*Pi};
//+
Curve Loop(1) = {2};
//+
Curve Loop(2) = {1};
//+
Plane Surface(1) = {1, 2};
//+
Transfinite Curve {2, 1} = 50 Using Progression 1;
//+
Extrude {0, 0, 4} {
  Surface{1}; Layers {50}; Recombine;
}

//+
Physical Surface("left", 7) = {4};
//+
Physical Surface("right", 8) = {1};
//+
Physical Surface("side", 9) = {3};
//+
Physical Volume(10) = {1};
