// Gmsh project created on Mon Apr  6 11:17:06 2026
SetFactory("OpenCASCADE");
//+
Box(1) = {-0.5, 0, -0.5, 0.2, 1, 1};
//+
Cylinder(2) = {-0.9, 0.5, -0, 1.5, 0, 0, 0.15, 2*Pi};
//+
BooleanUnion{ Volume{1}; Delete; }{ Volume{2}; Delete; }
//+
Physical Surface("leftend", 19) = {8};
//+
Physical Surface("rightend", 20) = {10};
//+
Physical Surface("left", 21) = {1};
//+
Physical Surface("right", 22) = {7};
//+
Physical Surface("lateral1", 23) = {6};
//+
Physical Surface("lateral2", 24) = {9};
//+
Physical Surface("top", 25) = {4};
//+
Physical Surface("bottom", 26) = {3};
//+
Physical Surface("front", 27) = {5};
//+
Physical Surface("back", 28) = {2};
//+
Physical Volume(29) = {1};
