// Gmsh project created on Thu Apr  2 15:25:16 2026
SetFactory("OpenCASCADE");
//+
Box(1) = {-0, -0.1, -0.3, 2, 0.5, 0.5};
//+
Physical Surface("left", 20) = {1};
//+
Physical Surface("right", 21) = {2};
//+
Physical Surface("top", 22) = {4};
//+
Physical Surface("bottom", 23) = {3};
//+
Physical Surface("back", 24) = {6};
//+
Physical Surface("front", 25) = {5};
//+
Physical Volume(26) = {1};
